package com.example.exo3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        LinearLayout monLinearLayout = new LinearLayout(this);
        monLinearLayout.setOrientation(LinearLayout.VERTICAL);

        TextView monTextView1 = new TextView(this);
        monTextView1.setText(R.string.saisi1);

        EditText editText = new EditText(this);
        editText.setHint("Name");
        //String value1 = editText.getText().toString();

        TextView monTextView2 = new TextView(this);
        monTextView2.setText(R.string.saisi2);

        EditText editText2 = new EditText(this);
        editText2.setHint("Surname");
        //String value2 = editText2.getText().toString();

        TextView monTextView3 = new TextView(this);
        monTextView3.setText(R.string.saisi3);

        EditText editText3 = new EditText(this);
        editText3.setHint("Domaine compétences");

        TextView monTextView4 = new TextView(this);
        monTextView4.setText(R.string.saisi4);

        EditText editText4 = new EditText(this);
        editText4.setHint("Numéro de téléphone");

        Button myButton = new Button(this);
        myButton.setText("Submit");

        Button button2 = new Button(this);
        button2.setText("Continuez");

        monLinearLayout.addView(monTextView1);
        monLinearLayout.addView(editText);
        monLinearLayout.addView(monTextView2);
        monLinearLayout.addView(editText2);
        monLinearLayout.addView(monTextView3);
        monLinearLayout.addView(editText3);
        monLinearLayout.addView(monTextView4);
        monLinearLayout.addView(editText4);
        monLinearLayout.addView(myButton);
        monLinearLayout.addView(button2);
        setContentView(monLinearLayout);

        /* Exercice5 */
        /* Dialogue de conversation */
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                .setTitle("Alert")
                .setMessage("Confirm your choice")
                .setPositiveButton("Ok", null)
                .setNegativeButton("Cancel", null);


        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
                Toast.makeText(MainActivity.this, "Choix pris en compte", Toast.LENGTH_SHORT).show();

            }
        });

        button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ActivityTwo.class);
                i.putExtra("value1", editText.getText().toString());
                i.putExtra("value2", editText2.getText().toString());
                i.putExtra("value3", editText3.getText().toString());
                i.putExtra("value4", editText4.getText().toString());
                startActivity(i);
            }

        });
    }
    }
