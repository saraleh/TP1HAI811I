package com.example.exo3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ActivityTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout monLinearLayout = new LinearLayout(this);
        monLinearLayout.setOrientation(LinearLayout.VERTICAL);

        Intent init = getIntent();
        String str1 = "", str2 = "", str3 = "", str4= "";

            str1 = init.getStringExtra("value1");
            str2 = init.getStringExtra("value2");
            str3 = init.getStringExtra("value3");
            str4 = init.getStringExtra("value4");



        TextView monTextView1 = new TextView(this);
        monTextView1.setText(str1);

        TextView monTextView2= new TextView(this);
        monTextView2.setText(str2);

        TextView monTextView3 = new TextView(this);
        monTextView3.setText(str3);

        TextView monTextView4 = new TextView(this);
        monTextView4.setText(str4);

        Button button1 = new Button(this);
        button1.setText("OK");

        Button button2 = new Button(this);
        button2.setText("RETOUR");

        monLinearLayout.addView(monTextView1);
        monLinearLayout.addView(monTextView2);
        monLinearLayout.addView(monTextView3);
        monLinearLayout.addView(monTextView4);
        monLinearLayout.addView(button1);
        monLinearLayout.addView(button2);
        setContentView(monLinearLayout);

        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }

        });

        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ActivityThree.class);
                i.putExtra("tel",  init.getStringExtra("value4").toString());
                startActivity(i);
            }

        });
    }
}