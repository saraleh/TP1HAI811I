package com.example.exo3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ActivityThree extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout monLinearLayout = new LinearLayout(this);
        monLinearLayout.setOrientation(LinearLayout.VERTICAL);

        ImageView simpleImageView=new ImageView(this);
        simpleImageView.setImageResource(R.drawable.telephone);

        Button button1 = new Button(this);
        button1.setText("Appeler");

        Intent i = getIntent();
        String str1 = "";

        str1 = i.getStringExtra("tel");

        TextView monTextView1 = new TextView(this);
        monTextView1.setText(str1);

        monLinearLayout.addView(simpleImageView);
        monLinearLayout.addView(monTextView1);
        monLinearLayout.addView(button1);

        setContentView(monLinearLayout);



        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+ i.getStringExtra("tel")));
                startActivity(intent);
            }

        });
    }
}