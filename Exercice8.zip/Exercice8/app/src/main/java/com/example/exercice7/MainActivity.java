package com.example.exercice7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        LinearLayout monLinearLayout = new LinearLayout(this);
        monLinearLayout.setOrientation(LinearLayout.VERTICAL);
        //monLinearLayout.setGravity(Gravity.CENTER);


        Typeface boldTypeface = Typeface.defaultFromStyle(Typeface.BOLD);

        TextView monTextView1 = new TextView(this);
        monTextView1.setText("Veuillez choisir un itinéraire");
        monTextView1.setTypeface(boldTypeface);

        TextView monTextView2 = new TextView(this);
        monTextView2.setText("Ville départ");

        TextView monTextView3 = new TextView(this);
        monTextView3.setText("Ville Arrivée");

        EditText editText1 = new EditText(this);
        editText1.setHint("ville depart");

        EditText editText2 = new EditText(this);
        editText2.setHint("ville arrivee");

        Button button1 = new Button(this);
        button1.setText("Chercher");

        monLinearLayout.addView(monTextView1);
        monLinearLayout.addView(monTextView2);
        monLinearLayout.addView(editText1);
        monLinearLayout.addView(monTextView3);
        monLinearLayout.addView(editText2);
        monLinearLayout.addView(button1);
        setContentView(monLinearLayout);

        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ActivityTwo.class);
                startActivity(i);
            }

        });

    }
    }
