package com.example.exercice7;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ActivityTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout monLinearLayout = new LinearLayout(this);
        monLinearLayout.setOrientation(LinearLayout.VERTICAL);



        List<String> hor= new ArrayList<>();


        for (int j=0; j<15; j++) {
            Random random = new Random();
            int heure, minute, heure2, train;
            heure = random.nextInt(21);
            minute = random.nextInt(60);
            heure2 = heure+2;
            train = random.nextInt(2000);

            String stringHeure = String.valueOf(heure);
            String stringMinute = String.valueOf(minute);
            String stringHeure2= String.valueOf(heure2);

            if(heure<10 ) stringHeure = "0" + stringHeure;
            if(heure2<10 ) stringHeure2 = "0" + stringHeure2;
            if(minute<10 ) stringMinute = "0" + stringMinute;


            hor.add("Train numero" +train+ "  "+"Depart:"+ stringHeure + ":" + stringMinute+ "   "+"Arrivée"+ "  "+ stringHeure2 + ":"+ stringMinute);
        }


        ListView myListView = new ListView(this);
        //Collections.sort(hor);
        monLinearLayout.addView(myListView);
        setContentView(monLinearLayout);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(ActivityTwo.this, android.R.layout.simple_list_item_1, hor);
        myListView.setAdapter(adapter);

    }
}