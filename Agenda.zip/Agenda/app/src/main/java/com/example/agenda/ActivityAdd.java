package com.example.agenda;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.type.Date;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ActivityAdd extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        LinearLayout monLinearLayout = new LinearLayout(this);
        monLinearLayout.setOrientation(LinearLayout.VERTICAL);

        TextView monTextView1 = new TextView(this);
        monTextView1.setText("Veuillez saisir une date ");

        EditText editText1 = new EditText(this);
        editText1.setHint("jj/mm/aaaa");

        TextView monTextView2 = new TextView(this);
        monTextView2.setText("Veuillez saisir le nom de l'évenement ");

        EditText editText2 = new EditText(this);
        editText2.setHint("name of the event");

        Button button1 = new Button(this);
        button1.setText("Ajouter ");

        Button button2 = new Button(this);
        button2.setText("Afficher l'évenement ");

        //DatePicker datePicker = new DatePicker(this);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int year = calendar.get(Calendar.YEAR);
        int month  = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);





        /*button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePicker.getYear();
                datePicker.getMonth();
                datePicker.getDayOfMonth();
            }
        });
       */

        CalendarView calenda = new CalendarView(this);

        monLinearLayout.addView(calenda);


        monLinearLayout.addView(monTextView1);
        monLinearLayout.addView(editText1);
        monLinearLayout.addView(monTextView2);
        monLinearLayout.addView(editText2);
        monLinearLayout.addView(button1);
        monLinearLayout.addView(button2);


        setContentView(monLinearLayout);

        final AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                .setTitle("Alert")
                .setMessage("Evenement ajouté avec succés")
                .setPositiveButton("OK", null);



        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();

                //Toast.makeText(MainActivity.this, "Choix pris en compte", Toast.LENGTH_SHORT).show();

            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent i = new Intent(getApplicationContext(), ActivityDisplay.class);
                //ArrayList<String> valeurs = new ArrayList<>();
                //String a = editText1.toString();
                //String b =editText2.toString();
                //valeurs.add(a + b);
                //i.putExtra("liste", valeurs);
                Toast.makeText(ActivityAdd.this, "Evenement ajouté", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), ActivityDisplay.class);
                i.putExtra("value1", editText1.getText().toString());
                i.putExtra("value2", editText2.getText().toString());

                startActivity(i);
            }
        });
      //  eventDay2 = CalendarDay.from(editText1);



    }
}