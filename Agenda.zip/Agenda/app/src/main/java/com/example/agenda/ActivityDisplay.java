package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class ActivityDisplay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout monLinearLayout = new LinearLayout(this);
        monLinearLayout.setOrientation(LinearLayout.VERTICAL);


        CalendarView calendar = new CalendarView(this);

        Intent init = getIntent();

        ArrayList<String> values = new ArrayList<>();
        String str2="", str1="";
        str1= init.getStringExtra("value1");
        str2= init.getStringExtra("value2");



        TextView monTextView1 = new TextView(this);
        monTextView1.setText("L'évenement "+ str2 + "a été ajouté le jour du "+ str1 );

        Button button1 = new Button(this);
        button1.setText("RETOUR");

        monLinearLayout.addView(calendar);
        monLinearLayout.addView(monTextView1);
        monLinearLayout.addView(button1);

        setContentView(monLinearLayout);

        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }

        });



    }
}