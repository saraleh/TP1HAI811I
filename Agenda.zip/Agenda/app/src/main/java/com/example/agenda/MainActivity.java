package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout monLinearLayout = new LinearLayout(this);
        monLinearLayout.setOrientation(LinearLayout.VERTICAL);

        Typeface boldTypeface = Typeface.defaultFromStyle(Typeface.BOLD);

        TextView monTextView1 = new TextView(this);
        monTextView1.setText("BIENVENUE DANS VOTRE AGENDA");
        monTextView1.setTypeface(boldTypeface);

        Button button1 = new Button(this);
        button1.setText("Ajouter un evenement");

        Button button2 = new Button(this);
        button2.setText("Afficher mes evenements");


        CalendarView calendarr = new CalendarView(this);



        monLinearLayout.addView(monTextView1);
        monLinearLayout.addView(calendarr);
        monLinearLayout.addView(button2);
        monLinearLayout.addView(button1);


        setContentView(monLinearLayout);

        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ActivityAdd.class);
                startActivity(i);
            }

        });

        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ActivityDisplay.class);
                startActivity(i);
            }

        });

    }
}