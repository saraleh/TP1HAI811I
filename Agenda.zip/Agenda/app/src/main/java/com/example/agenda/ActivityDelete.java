package com.example.agenda;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

public class ActivityDelete extends AppCompatActivity
{

}